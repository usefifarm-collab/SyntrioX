# Infrastructure

Phase 1 keeps infrastructure local via docker-compose.yml at the repo root.
Deployment manifests (IaC) will be added in later phases.
