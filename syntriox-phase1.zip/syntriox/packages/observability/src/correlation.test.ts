import { describe, expect, it } from "vitest";
import {
  getCorrelationContext,
  getCorrelationId,
  newCorrelationId,
  runWithCorrelation,
} from "./correlation";

describe("correlation", () => {
  it("propagates the context across the async chain", async () => {
    const id = newCorrelationId();
    await runWithCorrelation({ correlationId: id }, async () => {
      await new Promise((r) => setTimeout(r, 1));
      expect(getCorrelationId()).toBe(id);
      expect(getCorrelationContext()?.correlationId).toBe(id);
    });
    expect(getCorrelationId()).toBeUndefined();
  });

  it("generates unique correlation ids", () => {
    expect(newCorrelationId()).not.toBe(newCorrelationId());
  });
});
