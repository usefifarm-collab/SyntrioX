import { randomUUID } from "node:crypto";
import { AsyncLocalStorage } from "node:async_hooks";

/**
 * Correlation context: connects Brain planning, execution, approvals,
 * costs and KPIs into one traceable chain (Master Architecture §14).
 */
export interface CorrelationContext {
  correlationId: string;
  missionId?: string;
  taskId?: string;
  actorId?: string;
}

const storage = new AsyncLocalStorage<CorrelationContext>();

/** Run `fn` with a correlation context attached to the whole async chain. */
export function runWithCorrelation<T>(ctx: CorrelationContext, fn: () => T): T {
  return storage.run(ctx, fn);
}

export function getCorrelationContext(): CorrelationContext | undefined {
  return storage.getStore();
}

export function getCorrelationId(): string | undefined {
  return storage.getStore()?.correlationId;
}

export function newCorrelationId(): string {
  return randomUUID();
}
