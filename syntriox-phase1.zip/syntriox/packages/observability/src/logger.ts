import pino from "pino";
import { getEnv } from "@syntriox/config";
import { getCorrelationContext } from "./correlation";

/**
 * Structured JSON logging. Every line carries service + component and,
 * when available, the active correlationId — so a Mission can be traced
 * end-to-end across web, worker, agents and tools.
 */
export function createLogger(component: string) {
  return pino({
    level: getEnv().LOG_LEVEL,
    base: { service: getEnv().SERVICE_NAME, component },
    mixin() {
      const ctx = getCorrelationContext();
      return ctx ? { correlationId: ctx.correlationId } : {};
    },
  });
}

export const logger = createLogger("app");
