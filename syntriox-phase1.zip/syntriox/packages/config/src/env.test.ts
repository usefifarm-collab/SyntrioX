import { describe, expect, it } from "vitest";
import { parseEnv } from "./env";

describe("parseEnv", () => {
  it("applies safe defaults to an empty source", () => {
    const env = parseEnv({});
    expect(env.NODE_ENV).toBe("development");
    expect(env.SERVICE_NAME).toBe("syntriox");
    expect(env.LOG_LEVEL).toBe("info");
    expect(env.HEALTH_PORT).toBe(8081);
  });

  it("rejects an invalid log level with a readable message", () => {
    expect(() => parseEnv({ LOG_LEVEL: "loud" })).toThrow(/LOG_LEVEL/);
  });

  it("coerces HEALTH_PORT to a positive integer", () => {
    const env = parseEnv({ HEALTH_PORT: "9090" });
    expect(env.HEALTH_PORT).toBe(9090);
  });
});
