import { z } from "zod";

/**
 * Central, validated environment configuration for every SyntrioX app.
 * Phase 1 scope: platform-level variables only. Domain-specific env vars
 * belong to their own packages as the architecture grows.
 */
export const EnvSchema = z.object({
  NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
  SERVICE_NAME: z.string().min(1).default("syntriox"),
  LOG_LEVEL: z.enum(["debug", "info", "warn", "error"]).default("info"),
  DATABASE_URL: z.string().min(1).optional(),
  REDIS_URL: z.string().min(1).optional(),
  HEALTH_PORT: z.coerce.number().int().positive().default(8081),
});

export type Env = z.infer<typeof EnvSchema>;

let cached: Env | null = null;

/** Parse an explicit source (used by tests). Throws a readable error on failure. */
export function parseEnv(source: Record<string, string | undefined>): Env {
  const result = EnvSchema.safeParse(source);
  if (!result.success) {
    const issues = result.error.issues
      .map((i) => `  - ${i.path.join(".")}: ${i.message}`)
      .join("\n");
    throw new Error(`Invalid environment configuration:\n${issues}`);
  }
  return result.data;
}

/** Get the validated environment for the current process (cached). */
export function getEnv(): Env {
  cached ??= parseEnv(process.env);
  return cached;
}

/** Test helper to reset the cache. */
export function resetEnvCache(): void {
  cached = null;
}
