import { randomUUID } from "node:crypto";
import { z } from "zod";

/**
 * Canonical event envelope (Master Architecture §13).
 * Every event is idempotently consumable and carries the minimum
 * required context: who, what, where, when, and why (correlation).
 */
export const EventEnvelopeSchema = z.object({
  eventId: z.string().uuid(),
  eventType: z.string().min(1),
  organizationId: z.string().nullable(),
  aggregateId: z.string().min(1),
  correlationId: z.string().min(1),
  timestamp: z.string().datetime(),
  actorId: z.string().nullable(),
  version: z.number().int().positive(),
  payload: z.record(z.unknown()),
});

export type EventEnvelope = z.infer<typeof EventEnvelopeSchema>;

/** Known domain events for SyntrioX v1.0 (extensible by design). */
export const SYNTRIOX_EVENT_TYPES = [
  "organization.created",
  "member.invited",
  "mission.created",
  "mission.started",
  "mission.revised",
  "mission.completed",
  "mission.failed",
  "task.created",
  "task.started",
  "task.completed",
  "agent.started",
  "agent.completed",
  "payment.intent.created",
  "payment.submitted",
  "payment.confirmed",
  "withdrawal.requested",
  "withdrawal.approved",
  "withdrawal.rejected",
  "wallet.connected",
  "ai.cost.recorded",
  "budget.threshold.reached",
] as const;

export type SyntrioEventType = (typeof SYNTRIOX_EVENT_TYPES)[number];

export interface CreateEventInput {
  eventType: SyntrioEventType | (string & {});
  aggregateId: string;
  organizationId?: string | null;
  actorId?: string | null;
  /** Reuse an existing correlationId to stay inside one trace chain. */
  correlationId?: string;
  version?: number;
  payload: Record<string, unknown>;
}

export function createEvent(input: CreateEventInput): EventEnvelope {
  const envelope: EventEnvelope = {
    eventId: randomUUID(),
    eventType: input.eventType,
    organizationId: input.organizationId ?? null,
    aggregateId: input.aggregateId,
    correlationId: input.correlationId ?? randomUUID(),
    timestamp: new Date().toISOString(),
    actorId: input.actorId ?? null,
    version: input.version ?? 1,
    payload: input.payload,
  };
  return EventEnvelopeSchema.parse(envelope);
}
