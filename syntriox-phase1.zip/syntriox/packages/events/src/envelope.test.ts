import { describe, expect, it } from "vitest";
import { EventEnvelopeSchema, createEvent } from "./envelope";

describe("event envelope", () => {
  it("fills defaults for id, timestamp, correlation and version", () => {
    const event = createEvent({
      eventType: "mission.created",
      aggregateId: "mission_123",
      organizationId: "org_1",
      payload: { goal: "launch campaign" },
    });
    expect(event.eventId).toBeDefined();
    expect(event.version).toBe(1);
    expect(event.correlationId).toBeDefined();
    expect(event.timestamp).toContain("T");
    expect(event.payload).toEqual({ goal: "launch campaign" });
    EventEnvelopeSchema.parse(event); // must remain valid
  });

  it("keeps a shared correlationId across one trace chain", () => {
    const a = createEvent({ eventType: "task.created", aggregateId: "t1", payload: {} });
    const b = createEvent({
      eventType: "task.started",
      aggregateId: "t1",
      correlationId: a.correlationId,
      payload: {},
    });
    expect(b.correlationId).toBe(a.correlationId);
  });

  it("rejects an event without an aggregateId", () => {
    expect(() =>
      createEvent({ eventType: "task.created", aggregateId: "", payload: {} }),
    ).toThrow();
  });
});
