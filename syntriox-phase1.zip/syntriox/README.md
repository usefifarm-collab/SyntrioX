# SyntrioX

Business Mission Operating System — Master Architecture v1.0.

## Phase 1 — Platform Foundation

Monorepo layout:

- `apps/web`      Next.js application (API boundary + UI), health endpoint at `/api/health`
- `apps/worker`   BullMQ worker process with its own health server
- `packages/config`        Zod environment validation
- `packages/observability` Structured logging (pino) + correlation IDs (AsyncLocalStorage)
- `packages/events`        Event envelope (Domain Events / Transactional Outbox model)
- `packages/db`            Prisma client + initial schema (OutboxEvent, AuditLog)

## Commands

```bash
pnpm install
docker compose up -d        # postgres + redis (local dev)
cp .env.example .env
pnpm typecheck              # TypeScript across the monorepo
pnpm test                   # vitest suites
pnpm build                  # next build
pnpm dev                    # web on :3000, worker health on :8081
```

Next phases must follow docs/Master Architecture v1.0 and the Phase 1 Definition of Done.
