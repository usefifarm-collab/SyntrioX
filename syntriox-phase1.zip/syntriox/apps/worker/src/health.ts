import http from "node:http";
import type { AddressInfo } from "node:net";

/**
 * Minimal health server for the worker process (DoD §28).
 * Deliberately dependency-free: the health endpoint must answer even
 * when Redis/queues are down.
 */
export function startHealthServer(
  port: number,
  state: () => { status: string; queues: string[] },
): Promise<http.Server> {
  return new Promise((resolve) => {
    const server = http.createServer((req, res) => {
      if (req.url === "/health" || req.url === "/healthz") {
        res.writeHead(200, { "content-type": "application/json" });
        res.end(
          JSON.stringify({
            status: state().status,
            service: "syntriox-worker",
            phase: "1-foundation",
            queues: state().queues,
            timestamp: new Date().toISOString(),
          }),
        );
        return;
      }
      res.writeHead(404).end();
    });
    server.listen(port, () => resolve(server));
  });
}

export type { AddressInfo };
