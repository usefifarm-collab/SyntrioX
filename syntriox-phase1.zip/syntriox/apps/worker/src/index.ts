import { getEnv } from "@syntriox/config";
import { createLogger, newCorrelationId, runWithCorrelation } from "@syntriox/observability";
import IORedis from "ioredis";
import { Queue, Worker } from "bullmq";
import { startHealthServer } from "./health";

const logger = createLogger("worker");
const env = getEnv();

const connection = new IORedis(env.REDIS_URL ?? "redis://127.0.0.1:6379", {
  maxRetriesPerRequest: null,
  enableOfflineQueue: true,
});

const QUEUE_NAME = "syntriox-tasks";

const queue = new Queue(QUEUE_NAME, { connection });

/**
 * Phase 1 placeholder processor. The Execution Contract (Phase 6) will
 * replace this body with real Human / Agent / Tool executors.
 */
const worker = new Worker(
  QUEUE_NAME,
  async (job) => {
    return runWithCorrelation(
      { correlationId: (job.data?.correlationId as string) ?? newCorrelationId() },
      async () => {
        logger.info({ jobId: job.id, name: job.name }, "task started");
        logger.info({ jobId: job.id, name: job.name }, "task completed");
        return { ok: true };
      },
    );
  },
  { connection },
);

worker.on("completed", (job) =>
  logger.info({ jobId: job.id, correlationId: getJobCorrelation(job) }, "worker job completed"),
);
worker.on("failed", (job, err) =>
  logger.error({ jobId: job?.id, err: err.message }, "worker job failed"),
);

function getJobCorrelation(job: { data?: unknown }): string | undefined {
  const data = job.data as { correlationId?: string } | undefined;
  return data?.correlationId;
}

async function main() {
  const server = await startHealthServer(env.HEALTH_PORT, () => ({
    status: "ok",
    queues: [QUEUE_NAME],
  }));

  logger.info({ port: env.HEALTH_PORT, queue: QUEUE_NAME }, "SyntrioX worker started");

  async function shutdown(signal: string) {
    logger.info({ signal }, "shutting down worker");
    await worker.close();
    await queue.close();
    connection.disconnect();
    server.close();
    process.exit(0);
  }

  process.on("SIGINT", () => void shutdown("SIGINT"));
  process.on("SIGTERM", () => void shutdown("SIGTERM"));
}

void main();
