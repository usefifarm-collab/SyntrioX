import { NextResponse } from "next/server";
import { getEnv } from "@syntriox/config";

export const dynamic = "force-dynamic";

/**
 * Phase 1 health endpoint (Definition of Done §28).
 * Fails soft: a missing dependency degrades the status, it never crashes
 * the process. Returns 200 when all configured deps are healthy,
 * 503 when any configured dependency is unavailable.
 */
export async function GET() {
  const env = getEnv();
  const checks: Record<string, "ok" | "unavailable" | "skipped"> = {};
  let ok = true;

  // PostgreSQL
  if (env.DATABASE_URL) {
    try {
      const { prisma } = await import("@syntriox/db");
      await prisma.$queryRaw`SELECT 1`;
      checks.database = "ok";
    } catch {
      checks.database = "unavailable";
      ok = false;
    }
  } else {
    checks.database = "skipped";
  }

  // Redis
  if (env.REDIS_URL) {
    try {
      const IORedis = (await import("ioredis")).default;
      const redis = new IORedis(env.REDIS_URL, {
        lazyConnect: true,
        connectTimeout: 1500,
        maxRetriesPerRequest: 1,
      });
      const pong = await redis.ping();
      checks.redis = pong === "PONG" ? "ok" : "unavailable";
      redis.disconnect();
      if (checks.redis === "unavailable") ok = false;
    } catch {
      checks.redis = "unavailable";
      ok = false;
    }
  } else {
    checks.redis = "skipped";
  }

  return NextResponse.json(
    {
      status: ok ? "ok" : "degraded",
      service: env.SERVICE_NAME,
      phase: "1-foundation",
      checks,
      timestamp: new Date().toISOString(),
    },
    { status: ok ? 200 : 503 },
  );
}
