export default function Home() {
  return (
    <main style={{ maxWidth: 720, margin: "0 auto", padding: "4rem 1.5rem" }}>
      <h1 style={{ fontSize: "2.5rem", letterSpacing: "-0.02em" }}>
        Syntrio<span style={{ color: "#6c5ce7" }}>X</span>
      </h1>
      <p style={{ color: "#9aa0b4", fontSize: "1.05rem", lineHeight: 1.7 }}>
        Business Mission Operating System — Phase 1: Platform Foundation is
        running. Brain, Workforce, Economy and Mission Engine arrive in the
        next phases, on this same foundation.
      </p>
      <a
        href="/api/health"
        style={{ color: "#6c5ce7", fontWeight: 600 }}
      >
        Health check →
      </a>
    </main>
  );
}
