import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "SyntrioX",
  description: "Business Mission Operating System",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body
        style={{
          fontFamily:
            "system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif",
          margin: 0,
          background: "#0a0a0f",
          color: "#e8e8f0",
        }}
      >
        {children}
      </body>
    </html>
  );
}
