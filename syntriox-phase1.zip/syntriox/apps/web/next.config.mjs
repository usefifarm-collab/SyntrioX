/** @type {import('next').NextConfig} */
const nextConfig = {
  // Next compiles workspace packages from source (main points at src/index.ts).
  transpilePackages: [
    "@syntriox/config",
    "@syntriox/db",
    "@syntriox/events",
    "@syntriox/observability",
  ],
};

export default nextConfig;
